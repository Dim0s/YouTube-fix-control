let VolumeDown = false
let ProgressDown = false
let LiveBadgeDown = false

const Int = setInterval(() => {
	if (location.href.includes("/watch?v=") ||
		location.href.includes("/embed/") ||
		location.href.includes("/live/")) {
		clearInterval(Int)
		const Int2 = setInterval(() => {
			const vol = document.querySelector('.ytp-volume-slider')
			const progress = document.querySelector('.ytp-progress-bar')
			const progressMove = document.querySelector('.ytp-progress-bar')
			const lBadge = document.querySelector('.ytp-live-badge')
			const player = document.querySelector('#movie_player')
			if (vol && progress && lBadge && player) {
				clearInterval(Int2)
				vol.addEventListener('mousedown', () => VolumeDown = true)
				progress.addEventListener('mousedown', () => ProgressDown = true)
				lBadge.addEventListener('mousedown', () => LiveBadgeDown = true)
				document.addEventListener('mouseup', () => {
					if (VolumeDown == true || ProgressDown == true || LiveBadgeDown == true) {
						VolumeDown = false
						ProgressDown = false
						LiveBadgeDown = false
						player.focus()
					}
				})
				progressMove.addEventListener('mousemove', () => 
				{
					progress.dispatchEvent(new MouseEvent('mouseover', {bubbles: true}));
				})
			}
		}, 500)
	}
}, 500)